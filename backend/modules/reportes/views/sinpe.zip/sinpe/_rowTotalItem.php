  <tr>
    <td class='kv-align-center kv-align-middle' data-col-seq='2'><strong>TOTAL ABONADO</strong></td>
    <td class='kv-align-center kv-align-middle' data-col-seq='3'></td>
    <td class='kv-align-center kv-align-middle' data-col-seq='3'></td>
    <td class='kv-align-center kv-align-middle' data-col-seq='3'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='3' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='3' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='4' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='4' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='4' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'></td>
    <td class='kv-align-right kv-align-middle' data-col-seq='4' style='mso-number-format: &quot;\#\,\#\#0\.00&quot;;'><strong><?= $total_abonado ?></strong></td>
  </tr>