<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>
  <head>
  <meta http-equiv='Content-Type' content='text/html;charset=utf-8'/>
  <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Exportar Hoja de Trabajo</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
  </head>
  <body>
  <table class='kv-grid-table table table-bordered table-striped kv-table-wrap' width="80%">
    <thead>
      <tr style="background-color: #f4f4f4;">
            <th class='kv-align-center kv-align-middle' colspan="9" data-col-seq='2' style='font-size:18px'>
                <strong>REPORTE SINPE MOVIL</strong>          
            </th>    
      </tr> 
    </thead>               
