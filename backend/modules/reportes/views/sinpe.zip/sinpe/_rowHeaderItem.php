<tr style="background-color: #C0C0C0;">
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 10%;'></th>
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 10%;'>FECHA</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 50%;'>REFERENCIA</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>METODO PAGO</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>BANCO</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>AGENTE COBRADOR</th>
  <th colspan="3" class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>COMENTARIO</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>TOTAL ABONADO</th>
</tr>