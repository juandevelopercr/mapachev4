<tr style="background-color: #C0C0C0;">
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 10%;'>CONSECUTIVO</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 10%;'>FECHA</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='2' style='width: 50%;'>CLIENTE</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>VENDEDOR</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>COBRADOR</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>CANTIDAD</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='3' style='width: 10%;'>DESCUENTO</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='4' style='width: 10%;'>IVA</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='4' style='width: 10%;'>EXONERACIÓN</th>
  <th class='kv-align-center kv-align-middle' data-col-seq='4' style='width: 10%;'>TOTAL</th>
</tr>